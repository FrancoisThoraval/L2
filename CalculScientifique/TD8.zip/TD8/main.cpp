#include <iostream>
#include "vecteur.h"

using namespace std;

class Matrix : public Vecteur<double> {
private:
  int _sizeX;
  int _sizeY;
public:
//  Matrix() : Vecteur<Vecteur<double>>();
  Matrix();
  ~Matrix();

  void setSizeX(int);
  void setSizeY(int);

  int getSizeX()const;
  int getSizeY()const;

  void reInit(int,int,double);
  void zero();
  void linearCombi(double,double,Matrix&);
  // void productMatCol(Matrix&);
  void productMat(Matrix&);                       // Cette fonction permet egalement de calculer PRODUCTMATCOL !
  void productMat(Matrix&,Matrix&);

  double& operator()(int ligne, int colonne){
    if((ligne<_sizeX) && (colonne <_sizeY)){
      return((*this)[ligne+colonne]);
    }
  }

  Matrix& operator=( Matrix& ma){
    for(double i = 0; i < ma.getSizeX() ; i++) {
      for(double j = 0; j < ma.getSizeY() ; j++){
        (*this)(i,j) = ma(i,j);
      }
    }
    this->_sizeX = ma.getSizeX();
    this->_sizeY = ma.getSizeY();
    return(*this);
  }


friend ostream& operator<<(ostream& os, Matrix& m){
  for(double i = 0;i<m.getSizeX();i++){
    for(double j = 0;j<m.getSizeY();j++){
        os<<m(i,j)<<" ";
    }
    os<<endl;
  }
  return(os);
}


//   friend ostream &operator<<( Matrix& m,ostream& os){
//     //ostream os;
//     for(double i = 0;i<m.getSizeX();i++){
//       for(double j = 0;j<m.getSizeY();j++){
//         os<<m(i,j);
//       }
//       os<<endl;
//     }
//     return(os);
//   }
 };

Matrix::Matrix(){

}

Matrix::~Matrix(){

}
void Matrix::setSizeX(int s){
  this->_sizeX = s;
}

void Matrix::setSizeY(int s){
  this->_sizeY = s;
}

int Matrix::getSizeX()const{
  return(this->_sizeX);
}

int Matrix::getSizeY()const{
  return(this->_sizeY);
}

void Matrix::reInit(int n, int p , double d){
  _sizeX = n;
  _sizeY = p;
  Vecteur<double>::reInit(n*p,d);
}

void Matrix::zero(){
  for(double i = 0;i< _sizeX * _sizeY;i++ ){
    (*this)[i]=0;
  }
}

void Matrix::linearCombi(double alpha,double beta,Matrix& B){
  //Vecteur<double>::add(alpha,*this,beta,B);
  for(double i =0;i<_sizeX * _sizeY;i++){
    (*this)[i]*=alpha;
  }
  for(double i =0;i<_sizeX * _sizeY;i++){
    B[i]*=beta;
  }
  for(double i =0;i<_sizeX * _sizeY;i++){
    (*this)[i]+=B[i];
  }
}

// void Matrix::productMat(Matrix &B){
//   std::cout << "=======================" << std::endl;
//   Matrix aux = (*this);
//   aux.reInit(B.getSizeX(),B.getSizeY(),0);
//   for(double i = 0; i < getSizeX();i++){
//      for(double j = 0;j < B.getSizeY();j++){
//       aux(i,j)=0;
//       for(double k =0;k < getSizeY();k++){
//         aux(i,j) +=   (*this)(i,k) * B(k,j);
//         cout<<"aux : "<<endl<<aux<<endl;
//       }
//      }
//   }
//    //cout<<aux<<endl;
//   (*this).reInit(aux.getSizeX(),aux.getSizeY(),0);
//   (*this) = aux;
//   std::cout << "==============================" << std::endl;
// }

void Matrix::productMat(Matrix& A,Matrix& B){
  // A.productMat(B);
  // cout<<A<<endl;
  // (*this)=A;
  for(double i = 0; i < A.getSizeX();i++){
     for(double j = 0;j < B.getSizeY();j++){
      (*this)(i,j)=0;
      for(double k =0;k < A.getSizeY();k++){
        (*this)(i,j) +=   A(i,k) * B(k,j);
      }
     }

  }
}

int main(){
Matrix a;
Matrix b;
Matrix c;
Matrix d;
Matrix e;
a.reInit(2,2,2);
b.reInit(2,2,2);
c.reInit(2,1,2);
d.reInit(2,1,2);
e.reInit(2,2,0);
cout<<"a"<<endl<<a<<endl;
cout<<"b"<<endl<<b<<endl;
cout<<"c"<<endl<<c<<endl;
cout<<"d"<<endl<<d<<endl;
cout<<"e"<<endl<<e<<endl;
//a.linearCombi(2,1,b);
cout<<"Product 1 "<<endl;
//a.productMat(d);
c.productMat(a,d);
cout<<c;
cout<<endl;
cout<<"Product 2 "<<endl;
e.productMat(a,b);
cout<<e;
cout<<endl;
}
